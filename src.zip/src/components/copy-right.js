import React from "react";
import { M_SOCIETY_COPYRIGHT } from "../common/constants"

export const CopyrightView = () => {
    return (
        <>
            <div className="foot-bottom">
                <h6>{M_SOCIETY_COPYRIGHT}</h6>
            </div>
        </>
    )
}